# renting_car

Car Renting Flutter project -
 * for database Sqflite has been used .
 * for login,signup simple logic has been builed (firebase authentication will be included soon).
 
 # All plugins list :
  - lottie:
  - sqflite: ^2.0.3
  - url_launcher:
  - image_picker:
  - intl:
  - path:
  - provider:
  - shared_preferences:
  - cool_alert: ^1.1.0
  
  * Funtionality wise work has been done .
  
  
# Admin :
   - Admin can Add car
   - Add Driver
   - Can delete them.
   - A relation has been build  between Car and driver. A driver can be asigned  with car when adding a new car.
   
 # User :
 - A user can choose car by searching name, showing driver experience and car capacity.
 - After selecting a car driver can change his or her selection then he/she can choose price/package and can buid own custom package as well.
 - Then he/she need to provide his/her full information to confirm the booking.
 - After that a booking confirmation will appear.
 
