package com.example.renting_car

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
